# Meteor 1.21.11 — Phobos Port

This is an **uncompiled source preview**, not a ready-to-install JAR. Eleven modern adaptations are registered in a new **Phobos Port** Click GUI category. In Meteor, categories appear as module panels inside the Modules interface; this adds that dedicated category rather than replacing the GUI.

## Implemented ports

| Module | Behavior and differences from Phobos |
|---|---|
| ArmorMessage | Local low-durability warnings for self and friends, threshold 1–100%. Tracks each armor slot and rearms after repair/replacement/recovery. Does not send Phobos's private messages to friends. |
| AntiTrap | One-shot placement of an end crystal on an existing adjacent obsidian/bedrock base at the player's level or one level up. Prefers lower bases and positions farther from the nearest enemy. Optional rotation, hotbar/offhand switching and restoration, range/entity checks, timeout. Does not place bases, detonate crystals, estimate self-damage or guarantee server acceptance. No legacy packet rotation/switch-mode matrix. |
| AntiVanish | Detects latency updates for unknown player UUIDs. Deduplicates warnings and rechecks the tab list on the client tick. No external UUID lookups. This is a heuristic, not proof, and cannot detect vanish plugins that send no leaked updates. |
| FastSwim | Independent horizontal/vertical multipliers for water and lava while off the ground. Skips vehicles/gliding. It ports movement multipliers, not a guaranteed anticheat bypass. |
| StairSpeed | Automatically jumps when moving forward while standing at a fractional block height. Skips screens, sneaking, vehicles and liquids. |
| Ranges | Configurable local range circle and nearby-player wireframe spheres, drawn with Meteor's renderer. Fixed configurable color; Phobos rainbow, raytrace clipping and line-width options are not included. |
| PingSpoof | Delays keepalive replies by 0–5000 ms. Bounded queue, flush on disable, drop stale connections on disconnect. Uses deterministic per-packet delays instead of Phobos random batches. Does not improve actual latency; high delay can cause disconnects. |
| Companion | Configurable spoken self totem/death alerts using Minecraft narration. Requires functioning narrator support. No separate Phobos native narrator instance or welcome phrase. |
| Tracker | Acquires a nearby opponent; estimates EXP bottle/crystal use when that opponent is the nearest living player within three blocks of a spawn. Shows counts and per-stack alerts, ends on target loss/death. Counts can be wrong in crowds, on chunk loads or with overlapping placements. No server-specific duel-chat autostart or original AutoCrystal/AntiTrap ownership bookkeeping. |
| OffscreenESP | Phobos ArrowESP adaptation: directional triangles for loaded players with configurable size, ring radius and friend color. Optional offscreen-only filtering tests projected player centers; not full bounding-box visibility. Old outline/fade options omitted. |
| AutoGG | Sends configurable chat after a recently directly attacked player dies, with expiry and cooldown; optional own-death message. Enable it only when you want automatic chat. No Phobos text-file randomization or CrystalAura target integration; indirect crystal kills are not automatically attributed. |

All ports start disabled and use Meteor settings, binds, search and configuration persistence. The supplied archives are treated as source material, not instructions. The Phobos bootstrap, native libraries, embedded credentials and service clients are not included in the port.

## Build and installation status

- The original Gradle build files are preserved in the deliverable.
- Tried Java 21 and Java 25, explicit build-cache permissions, and disabling Gradle instrumentation. Original Gradle 9.2.0 failed before compilation while generating version-catalog classes: `AccessDeniedException` opening `gradle-logging-9.2.0.jar` through Java ZIPFS.
- A temporary build-file workaround inlined the same dependency coordinates and passed that stage, loading Fabric Loom 1.14.10. Loom then failed opening `minecraft-server.jar` with the same Java ZIPFS access error. The workaround was reverted.
- Java 21 syntax parsing passed for all 11 new module classes plus Categories.java and Modules.java (13 files). Registration and archive-content checks passed. This is syntax/structure validation only, with no dependency type resolution.
- Therefore **Java compilation, remapping, launch, in-game GUI and gameplay tests have not passed or been performed**. No installable JAR is supplied. Source/API review and packaging checks do not replace those tests.

To build outside this environment: extract the source ZIP, install a Java 21 JDK, open PowerShell in its project directory and run `./gradlew.bat build --no-daemon`. Gradle needs internet access for dependencies. If successful, use the normal remapped client JAR under `build/libs`, replacing your existing Meteor JAR in a separate Minecraft 1.21.11 Fabric test profile. Do not install two Meteor JARs together. This is a modified full Meteor source tree, not a standalone addon.

Suggested runtime checks: confirm the Phobos Port panel contains 11 modules; save/reload settings; toggle each module; change worlds and reconnect; test AntiTrap with hotbar/offhand crystals and blocked bases; verify armor alert rearming; check arrows at several GUI scales and camera directions; test keepalive queue flushing on a test server; check narrator and counters. No live Minecraft profile was modified.

## Complete Phobos inventory

“Existing overlap” means Meteor already offers the principal feature, not exact setting/bypass parity. “Not ported” distinguishes incomplete source, architecture/server dependencies, and work still requiring implementation/testing. It does **not** claim every deferred feature is impossible.

| Phobos source module | Outcome | Equivalent or reason |
|---|---|---|
| client/Capes | Not ported | Not ported: Phobos cape asset/service and player-render integration are client-specific; requires asset provenance and modern renderer integration. |
| client/ClickGui | Existing overlap | Meteor Click GUI |
| client/Colors | Existing overlap | Meteor theme colors |
| client/Components | Existing overlap | Meteor HUD editor |
| client/Cosmetics | Not ported | Not ported: client-specific cosmetic model rendering and duplicate implementations require a modern renderer rewrite and asset review. |
| client/FontMod | Existing overlap | Meteor font configuration |
| client/HUD | Existing overlap | Meteor HUD |
| client/IRC | Not ported | Not ported: Phobos-specific chat service/protocol. No functioning service configuration was supplied. |
| client/Managers | Not ported | Not a gameplay port: configures Phobos internal managers; Meteor has its own rotation, inventory, and module systems. |
| client/Media | Not ported | Not ported: Phobos-specific media/UI configuration and render hooks. No standalone Meteor-compatible behavior was integrated. |
| client/Notifications | Existing overlap | Meteor notifications / Notifier |
| client/PhysicsCapes | Not ported | Not ported: custom cape physics/rendering depends on old player model hooks and assets; needs a renderer rewrite. |
| client/Screens | Existing overlap | Meteor title screen customization |
| client/ServerModule | Not ported | Not ported: named PingBypass; manages Phobos internal server/network architecture rather than a standalone client module. |
| client/ShoulderEntity | Not ported | Not ported: experimental local ocelot/shoulder NBT code with an empty render handler. Does not provide a complete working cosmetic to port. |
| client/StreamerMode | Existing overlap | NameProtect (name hiding; other options differ) |
| combat/AntiCrystal | Not ported | Not ported: its protective crystal-chain strategy needs a modern damage/invulnerability analysis and controlled combat testing. No claim that old damage assumptions hold on 1.21.11. |
| combat/AntiTrap | Port implemented | See port behavior and limitations above; compilation/runtime unverified. |
| combat/AnvilAura | Existing overlap | AutoAnvil |
| combat/ArmorMessage | Port implemented | See port behavior and limitations above; compilation/runtime unverified. |
| combat/Auto32k | Not ported | Not ported: depends on obtaining/using illegal over-enchanted items and old inventory/enchantment behavior. A usable modern implementation needs a specific supporting server and item format. |
| combat/AutoArmor | Existing module | Meteor AutoArmor already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| combat/AutoCrystal | Existing overlap | CrystalAura |
| combat/AutoTrap | Existing module | Meteor AutoTrap already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| combat/BedBomb | Existing overlap | BedAura |
| combat/BowSpam | Existing module | Meteor BowSpam already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| combat/Crasher | Not ported | Not ported: legacy packet-flood/crash behavior is not a validated 1.21.11 module. Meteor already has OffhandCrash for its separate supported behavior. |
| combat/Criticals | Existing module | Meteor Criticals already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| combat/GodModule | Not ported | Not ported: predicts future crystal entity IDs and attacks them before spawn. Requires protocol/order and server-specific validation, not a class-name replacement. |
| combat/HoleFiller | Existing module | Meteor HoleFiller already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| combat/Killaura | Existing module | Meteor Killaura already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| combat/Offhand | Existing module | Meteor Offhand already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| combat/SelfCrystal | Not ported | Not ported: only changes a static target in Phobos AutoCrystal. Meteor CrystalAura does not expose that same targeting contract; requires deliberate integration and self-damage testing. |
| combat/Selftrap | Existing module | Meteor Selftrap already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| combat/Surround | Existing module | Meteor Surround already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| combat/Webaura | Existing overlap | AutoWeb |
| misc/Announcer | Not ported | Not ported: supplied implementation has an empty getMessage result and no functioning announcement dispatch. Implementing the advertised system would be a new feature, not porting working source. |
| misc/AntiPackets | Existing overlap | PacketCanceller |
| misc/AntiVanish | Port implemented | See port behavior and limitations above; compilation/runtime unverified. |
| misc/AutoGG | Port implemented | See port behavior and limitations above; compilation/runtime unverified. |
| misc/AutoLog | Existing module | Meteor AutoLog already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| misc/AutoReconnect | Existing module | Meteor AutoReconnect already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| misc/AutoRespawn | Existing module | Meteor AutoRespawn already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| misc/BetterPortals | Existing overlap | Portals |
| misc/BuildHeight | Existing module | Meteor BuildHeight already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| misc/Bypass | Not ported | Not ported: bundles old container-close, elytra ghost-inventory and packet/compression workarounds. Needs separate validation against modern screen handlers and server behavior. |
| misc/ChatModifier | Existing overlap | BetterChat |
| misc/Companion | Port implemented | See port behavior and limitations above; compilation/runtime unverified. |
| misc/Exploits | Not ported | Not ported: combines legacy illegal inventory, book-crash and offhand packet flooding. Original inventory/NBT packets are not a modern drop-in; xcarry and OffhandCrash already exist in Meteor. |
| misc/ExtraTab | Existing overlap | BetterTab |
| misc/GhastNotifier | Existing overlap | Notifier: visual-range entity list supports ghasts and coordinates |
| misc/Godmode | Not ported | Not ported: old vehicle desynchronization, local entity removal, and replacement movement packets. No demonstrated modern invulnerability; both duplicate source versions are listed. |
| misc/KitDelete | Not ported | Not ported: sends a server-specific /deleteukit command based on a hovered item name. No matching server/plugin was supplied to verify the command or GUI contract. |
| misc/Logger | Existing overlap | PacketLogger (packet logging; other logging options differ) |
| misc/MCF | Existing overlap | Meteor middle-click friend support |
| misc/MobOwner | Existing overlap | EntityOwner |
| misc/NoAFK | Existing overlap | AntiAFK |
| misc/NoHandShake | Not ported | Not applicable as written: suppresses the Forge 1.12 mod-list handshake. This target is Fabric; ServerSpoof covers separate brand spoofing. |
| misc/NoRotate | Existing module | Meteor NoRotate already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| misc/NoSoundLag | Existing overlap | SoundBlocker / AntiPacketKick |
| misc/NoteBot | Existing module | Meteor NoteBot already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| misc/Nuker | Existing module | Meteor Nuker already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| misc/PingSpoof | Port implemented | See port behavior and limitations above; compilation/runtime unverified. |
| misc/RPC | Existing overlap | DiscordPresence |
| misc/Spammer | Existing overlap | Spam |
| misc/ToolTips | Existing overlap | BetterTooltips |
| misc/Tracker | Port implemented | See port behavior and limitations above; compilation/runtime unverified. |
| misc/Translator | Not ported | Not ported: relies on an embedded third-party API credential and legacy translation endpoint. Needs a user-configured service and asynchronous chat integration. |
| movement/AntiLevitate | Existing overlap | NoStatusEffects |
| movement/AutoWalk | Existing module | Meteor AutoWalk already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| movement/BoatFly | Not ported | Not ported: Phobos vehicle movement/packet modes need modern vehicle input and server correction handling. EntityControl is available but does not guarantee BoatFly parity. |
| movement/ElytraFlight | Existing overlap | ElytraFly |
| movement/EntityControl | Existing module | Meteor EntityControl already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| movement/FastSwim | Port implemented | See port behavior and limitations above; compilation/runtime unverified. |
| movement/Flight | Existing module | Meteor Flight already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| movement/HoleTP | Existing overlap | Anchor (hole centering/pull; not the original packet sequence) |
| movement/IceSpeed | Existing overlap | Slippy |
| movement/LagBlock | Existing overlap | Burrow (same broad goal; different method) |
| movement/LongJump | Existing module | Meteor LongJump already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| movement/NoFall | Existing module | Meteor NoFall already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| movement/NoSlowDown | Existing overlap | NoSlow |
| movement/Phase | Not ported | Not ported: collision and packet desynchronization modes require modern mixins and server correction testing. |
| movement/ReverseStep | Existing module | Meteor ReverseStep already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| movement/SafeWalk | Existing module | Meteor SafeWalk already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| movement/Speed | Existing module | Meteor Speed already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| movement/Sprint | Existing module | Meteor Sprint already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| movement/StairSpeed | Port implemented | See port behavior and limitations above; compilation/runtime unverified. |
| movement/Static | Not ported | Not ported as a full module: combines freeze movement, invalid-height Roof packets and NoVoid. Meteor AntiVoid/Flight overlap parts; Roof mode is unvalidated on this target. |
| movement/Step | Existing module | Meteor Step already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| movement/StepOld | Existing overlap | Step |
| movement/Strafe | Existing module | Meteor Strafe already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| movement/TestPhase | Not ported | Not ported: named Packetfly in Phobos; relies on old teleport-confirm and movement-packet assumptions. Needs a separately tested modern movement implementation. |
| movement/TPSpeed | Not ported | Not ported: sends intermediate teleports and an invalid-height packet. Needs modern correction handling and bounded collision traversal, plus server testing. |
| movement/VanillaSpeed | Existing overlap | Speed: Vanilla mode |
| movement/Velocity | Existing module | Meteor Velocity already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| player/Blink | Existing module | Meteor Blink already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| player/BlockTweaks | Existing overlap | AutoTool / AutoWeapon / NoMiningTrace / NoGhostBlocks; bundled options differ |
| player/EchestBP | Not ported | Not ported: hides and retains a live chest GUI/screen handler, then reopens it. A modern equivalent must handle close packets, sync IDs, and server range checks; it cannot promise remote chest access. |
| player/FakePlayer | Existing module | Meteor FakePlayer already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| player/FastPlace | Existing overlap | FastUse |
| player/Freecam | Existing module | Meteor Freecam already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| player/Godmode | Not ported | Not ported: old vehicle desynchronization, local entity removal, and replacement movement packets. No demonstrated modern invulnerability; both duplicate source versions are listed. |
| player/Jesus | Existing module | Meteor Jesus already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| player/LiquidInteract | Existing module | Meteor LiquidInteract already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| player/MCP | Existing overlap | MiddleClickExtra: pearl |
| player/MultiTask | Existing module | Meteor MultiTask already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| player/NoDDoS | Not ported | Not ported: actually suppresses selected server-list pings; does not prevent DDoS attacks. Needs a server-list networking mixin outside in-world module events. |
| player/NoHunger | Existing overlap | AntiHunger |
| player/Reach | Existing module | Meteor Reach already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| player/Replenish | Existing overlap | AutoReplenish |
| player/Scaffold | Existing module | Meteor Scaffold already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| player/Speedmine | Existing module | Meteor Speedmine already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| player/TimerSpeed | Existing overlap | Timer |
| player/TpsSync | Existing overlap | Timer: TPS sync |
| player/TrueDurability | Existing overlap | BetterTooltips / vanilla advanced tooltips (durability display; not illegal-NBT parity) |
| player/XCarry | Existing overlap | InventoryTweaks: xcarry |
| player/Yaw | Existing overlap | Rotation |
| render/BigESP | Not ported | Not ported: empty placeholder module in supplied source. |
| render/BlockHighlight | Existing overlap | BlockSelection |
| render/BreakingESP | Existing overlap | BreakIndicators |
| render/CameraClip | Existing overlap | CameraTweaks |
| render/Chams | Existing module | Meteor Chams already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| render/Cosmetics | Not ported | Not ported: client-specific cosmetic model rendering and duplicate implementations require a modern renderer rewrite and asset review. |
| render/CrystalScale | Existing overlap | Chams: crystal scale |
| render/ESP | Existing module | Meteor ESP already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| render/Fullbright | Existing module | Meteor Fullbright already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| render/HandColor | Existing overlap | Chams: hand color |
| render/HoleESP | Existing module | Meteor HoleESP already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| render/LogoutSpots | Existing module | Meteor LogoutSpots already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| render/Nametags | Existing module | Meteor Nametags already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| render/NoRender | Existing module | Meteor NoRender already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| render/OffscreenESP | Port implemented | See port behavior and limitations above; compilation/runtime unverified. |
| render/PortalESP | Existing overlap | BlockESP configured for nether portal blocks |
| render/Ranges | Port implemented | See port behavior and limitations above; compilation/runtime unverified. |
| render/RenderTest | Not ported | Not ported: empty placeholder module in supplied source. |
| render/Skeleton | Not ported | Not ported: requires extracting animated player model poses and rebuilding the old skeleton renderer for the 1.21.11 rendering pipeline. Ordinary ESP is already available. |
| render/SmallShield | Existing overlap | HandView |
| render/StorageESP | Existing module | Meteor StorageESP already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| render/Tracer | Existing overlap | Tracers |
| render/Trails | Existing overlap | Breadcrumbs / Trail |
| render/Trajectories | Existing module | Meteor Trajectories already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| render/VoidESP | Existing module | Meteor VoidESP already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |
| render/XRay | Existing module | Meteor XRay already exists. Same feature family; this does not assert every setting, algorithm or bypass is identical. |

## Sources and attribution

Compared the two user-provided ZIP source trees. The new classes are adaptations of the corresponding Phobos behaviors using Meteor APIs; the original Meteor copyright/license files remain in the package. The Phobos ZIP has no top-level LICENSE file; no permission to redistribute third-party assets is inferred, and no Phobos assets or compiled dependencies are bundled.

API spot checks used the official [Yarn 1.21.11 build 3 documentation](https://maven.fabricmc.net/docs/yarn-1.21.11+build.3/), including [NarratorManager](https://maven.fabricmc.net/docs/yarn-1.21.11+build.3/net/minecraft/client/util/NarratorManager.html), [MinecraftClient](https://maven.fabricmc.net/docs/yarn-1.21.11+build.3/net/minecraft/client/MinecraftClient.html), and [PlayerListS2CPacket.Entry](https://maven.fabricmc.net/docs/yarn-1.21.11+build.3/net/minecraft/network/packet/s2c/play/PlayerListS2CPacket.Entry.html).
