# Meteor + Phobos + Impact port

This is a modified full Meteor 1.21.11 source project based on the previously tested Meteor + Phobos build. It adds 14 independently configured Impact behavior adaptations, an Impact GUI and an Impact HUD. Its separate GUI also exposes 50 existing modules under familiar Impact names. Those shared entries are shortcuts to the existing implementation, not independent copies of Impact's algorithms.

The uploaded Impact archive identifies itself as Impact 3.0 and includes patched Minecraft 1.10.2 source (protocol 210). This package does not run a second 1.10.2 Minecraft client inside Meteor. It hosts the adapted features on Meteor's existing Fabric entrypoint and produces one client JAR when built.

## Open and use

- Your existing Meteor/Phobos GUI key and selected theme stay as they were. Opening Impact does not select a global theme.
- **Right Alt** opens Impact. Alternatively, open the new **Impact** category in your existing GUI and toggle **Impact GUI**. Rebind that module if Right Alt is already in use.
- Left click toggles; right click expands settings; middle click binds. Shift + right click opens the full setting editor. Drag headers; right click a header to collapse it; scroll over a panel. Ctrl + F searches. Right click numeric values to type them; Enter commits, Escape cancels.
- **[M]** means a shared Meteor module; **[P]** means the shared Phobos PingSpoof. Changing its toggle, settings or bind changes the same module everywhere. Tooltips name the underlying module. Enabling a broad module such as CameraTweaks, InventoryTweaks or EntityControl does not automatically configure the specific legacy behavior; use its settings.
- The **HUD** toolbar button toggles Impact HUD; right click opens its settings. HUD defaults off. Phobos HUD takes priority if both are enabled; turn Phobos HUD off to see Impact, or disable Impact HUD's `defer-to-phobos` setting to deliberately overlay them.
- Impact HUD has Flare and Direkt list animation styles. Hold **Left Alt + Up/Down/Left/Right** for its tab menu: select a category, Right to open, Up/Down to select a module, Right again to toggle, Left to return. These keys are not reserved globally; avoid assigning competing module binds to the same combination.
- **Style** edits Impact's palette and panel width. **Reset** restores panel positions. **Back** closes to the parent screen/game. Advanced setting editors use Meteor's widgets with Impact colors.

Impact modules use `impact-*` identifiers and have independent settings in Meteor's normal config/profile system. Shared entries use their original identifiers and config. Impact panel positions, collapse states and style save separately in `meteor-client/gui/impact-port.nbt`; expansion of individual module settings, scroll offsets and search text are session-only. Old Impact config files are not imported. Friends, commands and profiles use Meteor's existing systems.

The 14 behavior ports default to pausing when a listed conflicting controller is enabled. This is a limited known-conflict list, not a general arbitration system. Two mutually conflicting Impact modules can both pause until one is disabled. Held inputs are released and temporary tool selections restored when a port stops. Avoid enabling competing movement, inventory or aiming modules together; other combinations still require runtime testing.

## Build and install

Use Java 21, extract the source ZIP, open a terminal in its `meteor-client-1.21.11` folder, and run:

```powershell
.\gradlew.bat build
```

Use the ordinary remapped client JAR in `build/libs`, not a `-sources` or development JAR. Replace the previous custom Meteor JAR in your Fabric 1.21.11 profile; do not install both copies. Existing Meteor/Phobos configuration is reused. This package contains source, not a compiled JAR.

## Verification and limitations

Java 21 syntax parsing passed for the 29 touched/new integration and Phobos files. The independent Impact panel geometry test passed 1,584 clipping, scrolling and placement checks. All 50 shared targets resolve to existing module declarations. A baseline comparison checks that the previous Phobos classes and GUI files remain byte-for-byte unchanged; only module/category registration and the HUD visibility hook change in existing Java files.

The full `gradlew build --no-daemon --stacktrace` attempt fails before compiling client source: Gradle's generated version-catalog class compilation hits `java.nio.file.AccessDeniedException` on `gradle-logging-9.2.0.jar` in this workspace. The log is supplied. Therefore this new integration has **not** passed Java type checking, a full build or an in-game launch here. The earlier Meteor/Phobos release was user-tested; that does not establish that this new Impact integration builds or runs. No Minecraft installation was modified.

After building, check both GUI keys, saved Impact layout after restart, inline/full settings, shared toggle synchronization, key release after disabling held-input ports, inventory swap-back, reconnect/death behavior, HUD priority and several GUI scales. Server-dependent movement and combat behavior remains unvalidated.

## Complete source-module inventory

“Adapted” can be a deliberately smaller modern implementation; read the details. “Shared entry” means broad feature availability through the existing host, not parity with old bypass modes or settings. “Not ported” distinguishes outstanding work and obsolete dependencies from an assertion that a feature is impossible. Nested mode helper classes are addressed after the table.

| Original Impact module | Outcome | Details |
|---|---|---|
| combat/Aimbot | Not ported | Not separately ported. SmoothAim is available, but the original instant snap aim and full entity filter need their own implementation. |
| combat/Aura | Shared entry | Uses existing kill-aura. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| combat/AutoArmor | Shared entry | Uses existing auto-armor. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| combat/AutoClicker | Shared entry | Uses existing auto-clicker. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| combat/BowAimbot | Shared entry | Uses existing bow-aimbot. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| combat/Criticals | Shared entry | Uses existing criticals. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| combat/HitBox | Shared entry | Uses existing hitboxes. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| combat/Pot | Not ported | Legacy timed potion selection/use controller omitted; modern inventory timing, hand and potion-component handling need a dedicated port. |
| combat/SmoothAim | Adapted | Visible-player smoothing with range/FOV/speed controls. Player-only; no original jitter, mob/animal options or old antibot heuristics. Default requires attack held. |
| combat/Soup | Not ported | Legacy timed soup-use/hotbar controller omitted; needs a modern item-use and inventory port and applicable server testing. |
| combat/Velocity | Shared entry | Uses existing velocity. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| exploit/AntiHunger | Shared entry | Uses existing anti-hunger. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| exploit/BedGodMode | Not ported | Old sleep/bed desynchronization relies on patched vanilla hooks and historical server behavior; no validated modern equivalent. |
| exploit/Firion | Not ported | Source explicitly targets 1.8 servers and spams movement packets to shorten burning. Not a validated 1.21.11 behavior. |
| exploit/Franky | Not ported | Module shell depends on modified vanilla integration; no standalone behavior that can be registered as a working modern module. |
| exploit/GhostHand | Not ported | Core behavior is in patched Block ray tracing with numeric block IDs. Needs modern raycast/mixin integration and block registry settings. |
| exploit/Ignite | Not ported | Needs modern flint-and-steel target placement, reach/rotation and item-use timing; not replaced by a misleading unrelated fire module. |
| exploit/PingSpoof | Shared entry | Uses existing ping-spoof. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| minigame/CopsAndCrims | Not ported | Legacy minigame item/recoil/aim assumptions require game-specific rewriting and validation. |
| minigame/Minestrike | Not ported | Legacy minigame weapon/item assumptions require game-specific rewriting and validation. |
| minigame/Murder | Not ported | Legacy role detection based on minigame item/state assumptions is not validated for a modern server. |
| minigame/PropHunt | Not ported | Legacy disguised entity/minigame detection requires a separate modern port and server validation. |
| minigame/QuakeCraft | Not ported | Legacy minigame aiming/weapon logic requires a separate modern port and server validation. |
| minigame/SneakyAssassians | Not ported | Legacy minigame role/entity assumptions require a separate modern port and server validation. |
| misc/Animations | Not ported | 1.7/1.8 sword-blocking and shield rendering hook into the old first-person renderer; need modern item render-state/mixin work. |
| misc/AntiBot | Not ported | Old GWEN/Watchdog/AAC heuristics are coupled to old servers and target filters. No claim they identify modern bots reliably. |
| misc/AntiCheat | Not ported | Local movement checks depend on legacy movement/tick assumptions; modern checks and false-positive validation are outstanding. |
| misc/AutoDisconnect | Shared entry | Uses existing auto-log. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| misc/AutoReconnect | Shared entry | Uses existing auto-reconnect. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| misc/CrosshairPlus | Not ported | Independent custom crosshair and vanilla-crosshair suppression need a dedicated rendering integration; not included in the HUD recreation. |
| misc/DeathCoords | Adapted | Local death coordinates and dimension, once per death. |
| misc/Disable | Not ported | Original shuts down Impact managers/hooks. That lifecycle cannot safely be applied to the shared Meteor host; use individual toggles. |
| misc/ItemSaver | Adapted | Moves a nearly broken held item into an empty main-inventory slot. Uses remaining durability, skips containers; cannot save it if inventory is full. |
| misc/MCF | Existing option/system | Use Meteor MiddleClickExtra in AddFriend mode (its default is Pearl), backed by the shared Friends system. No independent Impact toggle. |
| misc/MineplexStaffDetector | Not ported | Historical staff/server detection data and panic handling are not a maintained modern detection system. |
| misc/RainbowEnchant | Not ported | Old fixed-function glint rendering needs a modern render-pipeline/shader port. |
| misc/ScreenshotUploader | Not ported | Old Imgur upload integration and credentials/service handling are not included. Normal local screenshots remain available. |
| misc/SkinBlinker | Not ported | Skin-part cycling is feasible but not implemented; needs saved model-part state and reliable restoration across disconnects. |
| misc/Unpack | Not ported | Numeric-ID log crafting and raw inventory clicks need recipe/component-aware crafting and transaction recovery; not implemented. |
| movement/AutoJump | Adapted | Held jump, released in screens/on disable; uses modern jump handling. |
| movement/AutoWalk | Adapted | Held forward, released in screens/on disable. |
| movement/BoatFly | Shared entry | Uses existing entity-control. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/ElytraPlus | Shared entry | Uses existing elytra-fly. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/FastFall | Shared entry | Uses existing reverse-step. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/FastLadder | Adapted | Original upward ladder motion with horizontal motion stopped. |
| movement/Flight | Shared entry | Uses existing flight. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/Glide | Adapted | Constant slow descent; skips vehicles, swimming, ladders and elytra. |
| movement/InventoryMove | Shared entry | Uses existing gui-move. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/Jesus | Shared entry | Uses existing jesus. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/Jetpack | Adapted | Jump-key vertical acceleration; adds a configurable upward speed cap. |
| movement/LongJump | Shared entry | Uses existing long-jump. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/NoPush | Existing option/system | Use the shared Velocity module and configure its entity/block/liquid push controls; no separate toggle. |
| movement/NoSlowDown | Shared entry | Uses existing no-slow. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/Parkour | Adapted | Jump at an unsupported block edge; skips sneaking and vehicles. |
| movement/Phase | Not ported | Legacy Latest/NoClip/SkipClip collision and packet modes are not validated against modern collision and server handling. |
| movement/SafeWalk | Shared entry | Uses existing safe-walk. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/ScaffoldWalk | Shared entry | Uses existing scaffold. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/Speed | Shared entry | Uses existing speed. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/Spider | Adapted | Normal wall climb only; old NCP mode omitted. |
| movement/Sprint | Shared entry | Uses existing sprint. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| movement/Step | Shared entry | Uses existing step. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/AntiAFK | Shared entry | Uses existing anti-afk. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/AutoEat | Shared entry | Uses existing auto-eat. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/AutoFish | Shared entry | Uses existing auto-fish. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/AutoMine | Adapted | Held attack on the crosshair target; no independent pathfinding. |
| player/AutoRespawn | Adapted | One respawn request per death screen. |
| player/AutoSteal | Shared entry | Uses existing inventory-tweaks. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/AutoTool | Adapted | Raw hotbar mining-speed comparison and swap-back; not Meteor enchantment-aware scoring. |
| player/Blink | Shared entry | Uses existing blink. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/FastBreak | Shared entry | Uses existing speed-mine. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/FastPlace | Shared entry | Uses existing fast-use. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/Freecam | Shared entry | Uses existing freecam. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/LiquidInteract | Shared entry | Uses existing liquid-interact. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/NoFall | Shared entry | Uses existing no-fall. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/NoRotate | Shared entry | Uses existing no-rotate. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| player/Retard | Not ported | Original Headless/Spinny packet rotation modes are not implemented; they would need coordination with other rotation owners. |
| player/Sneak | Adapted | Normal held-sneak only; old packet mode omitted. |
| player/Timer | Shared entry | Uses existing timer. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/AntiBlind | Existing option/system | Use shared NoRender blindness overlay option; not a separate toggle. |
| render/Breadcrumbs | Shared entry | Uses existing breadcrumbs. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/Brightness | Shared entry | Uses existing fullbright. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/CameraClip | Shared entry | Uses existing camera-tweaks. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/Chams | Shared entry | Uses existing chams. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/ClickGui | Adapted | Separate Impact-style dark/blue category GUI, draggable/collapsible panels, hover ON/OFF badges, settings, search and binds. Native Minecraft font; layout recreated, not pixel-exact. |
| render/ESP | Shared entry | Uses existing esp. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/HUD | Adapted | Blue watermark, Flare/Direkt list spacing, per-module colors, effects, coordinates, stats and tab menu. Native font; no old entity-count section, user badges or font/service backend. |
| render/ItemPhysics | Shared entry | Uses existing item-physics. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/LiquidVision | Existing option/system | Use shared NoRender liquid/fog options as applicable; exact old underwater appearance is not recreated. |
| render/Nametags | Shared entry | Uses existing nametags. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/NoHurtCam | Existing option/system | Use the vanilla damage-tilt strength option; no separate Impact toggle. Modern API: [GameOptions.getDamageTiltStrength](https://maven.fabricmc.net/docs/yarn-1.21.11+build.3/net/minecraft/client/option/GameOptions.html#getDamageTiltStrength()). |
| render/NoRender | Shared entry | Uses existing no-render. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/PCP | Not ported | Old patched OpenGL color behavior needs a modern render-pipeline implementation. |
| render/Radar | Not ported | Original skin/entity radar and Static/Dynamic modes are not recreated. Meteor HUD offers its own radar separately. |
| render/StorageESP | Shared entry | Uses existing storage-esp. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/Tracers | Shared entry | Uses existing tracers. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/Trajectories | Shared entry | Uses existing trajectories. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/Waypoints | Shared entry | Uses existing waypoints. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| render/Wireframe | Not ported | Old polygon-mode rendering is not a drop-in for modern render pipelines; requires a new line-rendering implementation. |
| world/AntiWeather | Existing option/system | Use shared NoRender: weather. This is an option inside NoRender, not an independently toggled Impact module. |
| world/Nuker | Shared entry | Uses existing nuker. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |
| world/Xray | Shared entry | Uses existing xray. Same toggle, settings and keybind in both GUIs; original Impact algorithms/modes are not ported. |

## Nested modes and other client systems

The original Aura Cancer/Delay/Multi/Single/Switch/Tick modes are not copied; Aura [M] is Meteor KillAura. Flight's AAC/Cubecraft/Hypixel/Mineplex/NCP/Vanilla/3D modes, Speed's AAC/Bhop/Boost/Float/LowHop/Vanilla/Vhop/YPort modes, Phase's Latest/NoClip/SkipClip modes and the original rotation/anticheat helper families are not ported. Shared Meteor modules expose their own modes and settings. The existence of a similarly named mode does not imply algorithm or server-bypass parity.

Impact's separate account/session manager, command dispatcher, friend store, config serializer, alt/service integrations, user/premium badges, original title screen, additional GUI implementations, original URW font renderer, OptiFine/shader modifications and patched vanilla classes are not bundled. Meteor supplies the client lifecycle and current rendering/input/network APIs. The new native-text Impact interface recreates the main dark/blue panel style, not every original animation or pixel. Click-panel expansion is immediate; the HUD list is animated. The minigame category is omitted because none of its modules are implemented.

Sources: the three user-provided Meteor, Phobos and Impact ZIP archives. Meteor's license, copyright notices, dependencies and build configuration remain intact. The new Impact code adapts behavior and appearance from the uploaded `me/zero/clarinet` source. No original Impact binary dependencies, Minecraft source/classes, fonts, account data or service credentials are added to the package. Historical Phobos reports included in the source describe the earlier work; this file describes the new integration.
