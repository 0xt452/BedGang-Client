# Phobos Classic GUI + HUD for Meteor 1.21.11

This revision adds a selectable **Phobos** GUI theme and a **Phobos Hud** module to the Meteor source from the previous delivery. All eleven earlier Phobos gameplay/utility ports remain included.

## Build and enable

1. Extract this source ZIP into a new directory. Build the same way you built the previous version: `./gradlew.bat build --no-daemon`. A Java 21 JDK is required. Optionally add `-Pbuild_number=phobos-classic` to distinguish the output filename.
2. Replace the previous Meteor JAR with the newly built normal client JAR from `build/libs`. Do not install two Meteor JARs together. This is a modified full Meteor client, not an addon.
3. In Meteor's module search, find **Phobos Gui** under **Phobos Port** and toggle it once. It selects the Phobos theme and opens the new GUI. Your existing Meteor GUI key then opens Phobos. Alternatively, choose **Phobos** in Meteor's **GUI → Theme** dropdown.
4. Click **HUD** in the new GUI's top strip to enable the classic HUD. Right-click **HUD** for its settings. You can also search for **Phobos Hud** and enable it directly.
5. Click **Meteor** in the top strip to switch back to the standard theme. HUD selection is independent: toggle Phobos Hud off to restore Meteor HUD rendering.

The GUI and HUD are opt-in. Your current theme and existing HUD layout are not replaced automatically on startup.

## Click GUI

Adapted from the uploaded Phobos `PhobosGui`, `Component`, `ModuleButton`, `Button`, and setting controls:

- Classic 88-pixel panels, gray headers, translucent black panel bodies, faint inactive rows, red enabled rows and gray inactive labels.
- Native Minecraft font with shadow, compact rows, and indented settings expanded below each module.
- Left-drag a category header to move it. Right-click it to collapse/expand it. Panel positions and collapse states persist in the Phobos theme configuration.
- Left-click a module to toggle it. Right-click to expand/collapse its settings. Middle-click to bind it. Shift + right-click opens its full Meteor settings screen.
- Boolean settings toggle; enum choices cycle forward with left-click and backward with right-click.
- Number settings have inline sliders. Right-click a number for exact entry. Sliders with an apply-on-release callback defer the change until release.
- Click a string to edit it. Ctrl+A clears the edit buffer; Enter commits and Escape cancels. Numeric input validates the allowed range and rejects non-finite values.
- Click Bind or middle-click a module, then press a key or extra mouse button. Delete/Backspace clears; Escape cancels. Complex settings—including colors, item/entity lists, and module-provided widgets—open the complete Meteor module editor via their row or **Full settings...**.
- Hover for descriptions. Long labels are clipped to the panel; descriptions and the full editor remain available.
- Scroll the hovered panel. Panels initially wrap onto multiple rows to fit the available GUI size. **Reset** arranges them again. Increase panel width in **GUI → Phobos Panels** for longer module names.
- **Search** or Ctrl+F filters by module name. **Tabs** opens Meteor's normal tabbed module screen using the Phobos palette so GUI settings, profiles, friends, macros and other tabs stay reachable.
- **GUI → Phobos Panels** also controls header color, optional outline, text shadow and rolling rainbow. The standard theme accent controls active-row color.

Modern adaptations: a small utility/search strip, wrapping and per-panel scrolling, inline +/- expansion indicators, and full-editor links for Meteor's richer setting types. This is a recreation of the original look and interactions, not the old Forge renderer running inside Fabric. Common Phobos controls are inline; specialized Meteor editors retain Meteor widget layouts.

## HUD

Adapted from the uploaded Phobos `HUD` implementation:

- Phobos watermark at top-left; optional version and customizable greeting.
- Bottom-right, width-sorted active module list with gray brackets and white module info. Entry/exit animations, alphabetical sorting, and a hidden-module list are configurable.
- Top-right potion effects, speed in km/h, TPS, ping and FPS. Optional local time, server brand and held-item durability.
- **Rendering Up** reverses the right-side layout: modules at the top and information at the bottom, as in Phobos.
- Bottom-left XYZ, equivalent Overworld/Nether coordinates, and direction/axis label. Coordinate conversion is omitted in other dimensions.
- Armor item icons and green-to-red durability percentages in the original arrangement above the hotbar; centered totem icon with inventory/offhand total.
- Optional text radar, configurable colors, GUI color synchronization, rolling rainbow, scale, margin and shadow.
- Optional packet-silence warning and a short center hit marker. The marker indicates your attack action, not server-confirmed damage.
- Chat clearance, debug/HUD-hidden handling, disconnect resets and vanilla item rendering.

The layout is the original fixed-corner style, configured through the Phobos Hud module; it is not a set of draggable Meteor HUD elements. **Replace Meteor HUD** temporarily suppresses Meteor HUD elements while Phobos Hud is active and preserves their saved layout and enabled state. The Meteor HUD editor still opens normally, without the Phobos HUD drawn over it.

Differences/omissions: no obsolete 2b2t queue service, old PingBypass backend, Phobos custom-font loader, native hit sounds, or exact old per-module color/animation implementation. The watermark says `Phobos 1.21.11`, not that this is an original Phobos 1.9 binary. Existing vanilla potion icons are retained. Very large panel widths on small windows may require rearranging panels or reducing Minecraft's GUI scale.

## Verification

- Java 21 syntax parsing passed for all 21 relevant source files, including the previous ports and new GUI/HUD integration.
- Compiled and executed the independent panel-geometry tests: **1,619 checks passed**, covering normal screen sizes, default/wider panels, scrolling after filtering/collapse, and clipped hitbox boundaries.
- Checked theme registration, GUI/HUD module registration, preservation of the eleven previous port files, and source-archive contents.
- The full Gradle build in this assistant environment still fails during generated version-catalog class compilation, before project compilation. A separate probe reproduces a Java `Path.toRealPath()` access failure on readable local files. The original Gradle build files have not been modified for this revision.
- You confirmed the previous delivery built and launched on your machine. **This GUI/HUD revision has not yet been fully compiled, launched or visually verified in Minecraft here.** Syntax and geometry checks are not an in-game test.

First in-game checks: open/close with your normal GUI bind; drag/collapse/reopen panels; edit a bool, number, enum and string; bind/unbind a module; filter/search/scroll; visit full settings and return; enable/disable HUD; change GUI scale; reconnect and reload settings; inspect armor/totems and both right-side orientations.

## Source notes

The previous `PHOBOS-PORT-REPORT.md` is retained as the historical report for the eleven earlier ports. Its earlier GUI/HUD deferral entries are superseded by this revision. No Phobos bootstrap, service credentials, native libraries or assets were copied into this implementation. Original Meteor copyright and license files remain intact.

Source/API review used the supplied Meteor and Phobos sources and official [Yarn 1.21.11 build 3 DrawContext documentation](https://maven.fabricmc.net/docs/yarn-1.21.11+build.3/net/minecraft/client/gui/DrawContext.html).
